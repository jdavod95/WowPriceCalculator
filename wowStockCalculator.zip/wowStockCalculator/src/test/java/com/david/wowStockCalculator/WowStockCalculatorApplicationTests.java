package com.david.wowStockCalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WowStockCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
